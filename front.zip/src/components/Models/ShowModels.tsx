import React, { useState, useEffect, useRef } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { BrowserRouter, HashRouter, Link, Route, NavLink } from "react-router-dom";
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import BasicCard from './ModelCard';

import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

//Model Card component
const Model = (props:any) => {
  const [modelState, setModelState] = useState(props);
  //<ul class="c-table__row" onClick=${() => alert(modelState.index)}>
  return (
    <div className="card"  key={modelState.model['_id_$oid']}>
      <div className="card-body">
        <h5 className="card-title">{modelState.model['object_name']}</h5>
        <p className="card-text">{modelState.key}</p>
        <Link className="btn btn-primary" to={`/transactions/${modelState.model['_id_$oid']}`}>
         Show dataset
        </Link>
      </div>   
      </div>    
    )
};

function ShowModels() {
  // Declare a new state variable, which we'll call "count"
  const [models, setModels] = useState([]);
  const componentIsMounted = useRef(true);
  console.log("loading Models List")
  useEffect(() => {
    fetch('http://127.0.0.1:8000/api/models', {
      method: 'GET',
      headers: {
       'Content-Type': 'application/json',
       'Authorization': JSON.stringify({'id':1,'username':'roman','email':'babe'})        
      },
   })
   .then((response) => response.json())
   .then((data) => {
      console.log(data);
      setModels(data)
      // Handle data
   })
   .catch((err) => {
      console.log(err.message);
   });
      return () => {
      componentIsMounted.current = false;
      };
  }, []);
  return (
    <div>
      <div className="row">
        {models.map((model,index) => {
        return (
            <Model model={model} key={index}/>
        )     
          })}
      </div> 
    </div>
  );
}

export default ShowModels;
